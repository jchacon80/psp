package ejemplos.ud01;

public class Test {

	public static void main(String[] args) {
		System.out.println("Start");
		for (String str : args) {
			System.out.println(str);
		}

	}

}
